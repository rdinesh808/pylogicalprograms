"""
Importing Python Patterns programs modules.
Official License By rdinesh808
mail Id: rdinesh808@gmail.com0
"""

from .DineshNamePattern import *
from .Pypatterns import *


# methods names
__all__ = ['Square_Pattern','Hollow_Square_Pattern', 'Square_With_Cross_Pattern', 'Left_Triangle_Star_Pattern',
           'Left_Downward_Triangle_Pattern','Right_Triangle_Star_Pattern', 'Right_Downward_Triangle_Pattern',
           'Hollow_Triangle_Star_Pattern', 'Pyramid_Pattern','Reverse_Pyramid_Pattern', 'Right_Pascal_Star_Pattern',
           'Left_Pascal_Star_Pattern', 'Hollow_Pyramid_Pattern', 'Plus_Pattern', 'Cross_Pattern', 'Heart_Pattern',
           'Diamond_Star_Pattern', 'Hollow_Diamond_Star_Pattern', 'Hourglass_Star_Pattern', 'print_dinesh']
