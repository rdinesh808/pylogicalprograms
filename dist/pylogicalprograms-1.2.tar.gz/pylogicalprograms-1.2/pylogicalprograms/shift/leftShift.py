
# 65536 32768 16384 8192 4096 2048 1024 512 256 128 64 32 16 8 4 2 1

def left_shift(number, lshift):
    shift = 2 ** lshift
    return number * shift
