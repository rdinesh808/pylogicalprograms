
def stringEvaluation(string):
    string = string.replace("/", "//")
    return eval(string)
